# 🧠 Knowledge Graph Pipeline — Semantic RAG

Pipeline completo de extracción, construcción y consulta de grafos de conocimiento a partir de manuales técnicos, con bucle de refinamiento iterativo.

---

## 📐 Arquitectura del Pipeline

```
Manual Técnico (PDF/TXT)
        │
        ▼
┌─────────────────────┐
│  Tarea 1: Ingesta   │  → Chunking dinámico con análisis de densidad
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  Tarea 2: Extracción│  → CoT → Entidades + Relaciones → TTL
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  Tarea 3: Merging   │  → Fusión en Triple Store (GraphDB)
└─────────┬───────────┘
          │
        ┌─┴──────────────────────┐
        ▼                        ▼
┌──────────────┐       ┌─────────────────────┐
│  Tarea 4:    │       │  Tarea 5: SPARQL     │
│  Golden Set  │       │  Generación + Val.   │
└──────┬───────┘       └──────────┬──────────┘
       │                          │
       └──────────┬───────────────┘
                  ▼
        ┌─────────────────────┐
        │  Tarea 6: Ejecución │  → Métricas vs Golden Set
        └─────────┬───────────┘
                  │
                  ▼
        ┌─────────────────────┐
        │  Tarea 7: Diagnóst. │  → Clasificación de errores
        └─────────┬───────────┘
                  │
                  ▼
        ┌─────────────────────┐
        │  Tarea 8: Refinem.  │  → Inyección + Re-loop ↺
        └─────────────────────┘
```

---

## 🗂️ Estructura del Repositorio

```
├── .github/
│   ├── workflows/          # CI/CD automático
│   └── ISSUE_TEMPLATE/     # Plantillas de issues
├── docs/                   # Documentación extendida
├── src/
│   ├── 1_ingestion/        # Chunking dinámico
│   ├── 2_extraction/       # Extracción CoT → TTL
│   ├── 3_merging/          # Fusión del grafo
│   ├── 4_evaluation_set/   # Generación del Golden Set
│   ├── 5_sparql/           # Interfaz de consulta semántica
│   ├── 6_execution/        # Ejecución y métricas
│   ├── 7_diagnostics/      # Diagnóstico de fallos
│   └── 8_refinement/       # Bucle de refinamiento
├── ontologies/             # Archivos .ttl generados
├── data/
│   ├── raw/                # Manuales originales (no versionados)
│   └── golden_set/         # Preguntas + respuestas esperadas
└── tests/                  # Tests unitarios e integración
```

---

## 🚀 Instalación

```bash
git clone https://github.com/tu-usuario/kg-pipeline.git
cd kg-pipeline
pip install -r requirements.txt
```

### Requisitos
- Python 3.10+
- GraphDB (local o remoto)
- Acceso a API de LLM (OpenAI / Anthropic)

---

## ⚙️ Uso Rápido

```bash
# 1. Procesar manual e ingesta
python src/1_ingestion/chunker.py --input data/raw/manual.pdf

# 2. Extraer entidades y relaciones
python src/2_extraction/extractor.py --chunks output/chunks/

# 3. Fusionar en grafo
python src/3_merging/merger.py --ttl-dir ontologies/

# 4. Ejecutar evaluación completa
python src/6_execution/evaluator.py --golden-set data/golden_set/

# 5. Diagnóstico y refinamiento automático
python src/8_refinement/agent.py --loop --threshold 0.85
```

---

## 📊 Métricas de Evaluación

| Métrica | Herramienta | Umbral |
|---|---|---|
| Similitud Semántica | SBERT (Coseno) | τ > 0.85 |
| Precisión de Términos | BERTScore | — |
| Cobertura de Entidades | Jaccard | — |

---

## 🌿 Flujo de Trabajo (Branching)

```
main          ← Código estable y validado
develop       ← Integración continua
feature/...   ← Nuevas funcionalidades
fix/...       ← Correcciones de bugs
experiment/...← Pruebas de modelos/estrategias
```

---

## 📋 Milestones

Cada Tarea tiene su propio Milestone en GitHub Issues:

- `M1` Ingestion Pipeline
- `M2` TTL Extraction
- `M3` Graph Merging
- `M4` Evaluation Dataset
- `M5` SPARQL Interface
- `M6` Execution & Metrics
- `M7` Diagnostics
- `M8` Refinement Loop

---

## 🤝 Contribución

1. Abre un Issue usando la plantilla correspondiente
2. Crea una rama `feature/` o `fix/` desde `develop`
3. Envía un Pull Request con tests incluidos
4. El CI validará TTL, SPARQL y métricas automáticamente

---

## 📄 Licencia

MIT
